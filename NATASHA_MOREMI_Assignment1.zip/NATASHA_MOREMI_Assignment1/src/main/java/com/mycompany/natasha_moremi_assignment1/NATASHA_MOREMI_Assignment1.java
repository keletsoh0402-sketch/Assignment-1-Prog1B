package com.mycompany.natasha_moremi_assignment1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class NATASHA_MOREMI_Assignment1 extends JFrame {

    public enum Category {
        INPATIENT,
        OUTPATIENT,
        EMERGENCY
    }

    public static class Client {
        String pid, fname, lname, gender, illness;
        int yrs;
        Category cat;
        
        Client() {}
        
        Client(String pid, String fname, String lname, int yrs, String gender, String illness, Category cat) {
            this.pid = pid; this.fname = fname; this.lname = lname; this.yrs = yrs;
            this.gender = gender; this.illness = illness; this.cat = cat;
        }
        
        String info() {
            return String.format("%s | %s %s | %d | %s | %s | %s", pid, fname, lname, yrs, gender, illness, cat);
        }
    }

    public static class Admitted extends Client {
        int wardNo;
        String bedNo;
        
        Admitted() { super(); this.cat = Category.INPATIENT; }
        
        Admitted(String pid, String fname, String lname, int yrs, String gender, String illness, int wardNo, String bedNo) {
            super(pid, fname, lname, yrs, gender, illness, Category.INPATIENT);
            this.wardNo = wardNo; this.bedNo = bedNo;
        }
        
        @Override
        String info() {
            return String.format("%s | %s %s | %d | %s | %s | %s | Ward: %d | Bed: %s",
                pid, fname, lname, yrs, gender, illness, cat, wardNo, bedNo);
        }
    }

    public static class Store {
        ArrayList<Client> list = new ArrayList<>();
        
        boolean save(Client c) { return find(c.pid) == null && list.add(c); }
        Client find(String pid) { for(Client c: list) if(c.pid.equalsIgnoreCase(pid)) return c; return null; }
        boolean edit(String pid, String f, String l, int y, String g, String ill, Category c) {
            Client cl = find(pid); if(cl == null) return false;
            cl.fname = f; cl.lname = l; cl.yrs = y; cl.gender = g; cl.illness = ill; cl.cat = c; return true;
        }
        boolean remove(String pid) { Client c = find(pid); return c != null && list.remove(c); }
        int total() { return list.size(); }
        ArrayList<Client> all() { return list; }
        void sortByLname() { Collections.sort(list, (a,b) -> a.lname.compareToIgnoreCase(b.lname)); }
        void sortByPid() { Collections.sort(list, (a,b) -> a.pid.compareToIgnoreCase(b.pid)); }
    }

    public static class BedCtrl {
        static final int MAX = 20;
        String[] beds = new String[MAX];
        Map<String, String> map = new HashMap<>();
        Map<String, Client> bedClient = new HashMap<>();
        Store db;
        
        BedCtrl(Store db) {
            this.db = db;
            for(int i=0; i<MAX; i++) beds[i] = String.format("B%02d", i+1);
        }
        
        boolean assign(String pid) {
            Client c = db.find(pid);
            if(c == null || c.cat != Category.INPATIENT || bedClient.containsValue(c)) return false;
            String free = freeBed();
            if(free == null) return false;
            map.put(free, pid); bedClient.put(free, c);
            if(c instanceof Admitted) { ((Admitted)c).bedNo = free; ((Admitted)c).wardNo = 1; }
            return true;
        }
        
        boolean release(String bed) {
            if(!map.containsKey(bed)) return false;
            map.remove(bed); bedClient.remove(bed); return true;
        }
        
        String freeBed() { for(String b: beds) if(!map.containsKey(b)) return b; return null; }
        int used() { return map.size(); }
        double percent() { return (double)used()/MAX*100; }
        boolean isFull() { return used() == MAX; }
        boolean taken(String b) { return map.containsKey(b); }
        Client get(String b) { return bedClient.get(b); }
        String[] getBeds() { return beds; }
        Map<String,String> getMap() { return map; }
    }

    Store db = new Store();
    BedCtrl bCtrl = new BedCtrl(db);
    JTabbedPane tabs;
    JTable tbl;
    DefaultTableModel mdl;
    JPanel bedPanel;
    JLabel usageL, totalL, occL;

    private final Color HEADER_COLOR = new Color(60, 20, 80);
    private final Color HEADER_TEXT = Color.WHITE;
    private final Color BUTTON_PRIMARY = new Color(0, 150, 136);
    private final Color BUTTON_SUCCESS = new Color(0, 200, 83);
    private final Color BUTTON_DANGER = new Color(244, 67, 54);
    private final Color BUTTON_WARNING = new Color(255, 193, 7);
    private final Color BUTTON_INFO = new Color(0, 188, 212);
    private final Color BUTTON_PURPLE = new Color(156, 39, 176);
    private final Color BUTTON_GRAY = new Color(120, 120, 120);
    private final Color BG_WHITE = Color.WHITE;
    private final Color TABLE_HEADER = new Color(60, 20, 80);
    private final Color BED_AVAILABLE = new Color(0, 200, 83);
    private final Color BED_OCCUPIED = new Color(244, 67, 54);
    private final Color STAT_CARD_1 = new Color(0, 150, 136);
    private final Color STAT_CARD_2 = new Color(0, 200, 83);
    private final Color STAT_CARD_3 = new Color(255, 193, 7);
    private final Color STAT_CARD_4 = new Color(244, 67, 54);
    private final Color STAT_CARD_5 = new Color(156, 39, 176);
    private final Color STAT_CARD_6 = new Color(0, 188, 212);

    public NATASHA_MOREMI_Assignment1() {
        setTitle("Moremi Hospital System");
        setSize(1080, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        add(header(), BorderLayout.NORTH);
        tabs = new JTabbedPane();
        tabs.setBackground(BG_WHITE);
        tabs.setForeground(Color.BLACK);
        tabs.addTab("Patients", patientTab());
        tabs.addTab("Beds", bedTab());
        tabs.addTab("Reports", reportTab());
        add(tabs, BorderLayout.CENTER);
        add(footer(), BorderLayout.SOUTH);
        refreshAll();
    }

    JPanel header() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(HEADER_COLOR);
        p.setPreferredSize(new Dimension(1080, 60));
        JLabel t = new JLabel("Moremi Patient Management");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(HEADER_TEXT);
        t.setHorizontalAlignment(SwingConstants.CENTER);
        p.add(t, BorderLayout.CENTER);
        JLabel sub = new JLabel("Natasha Moremi");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(new Color(200, 180, 210));
        sub.setHorizontalAlignment(SwingConstants.RIGHT);
        sub.setBorder(BorderFactory.createEmptyBorder(0,0,5,20));
        p.add(sub, BorderLayout.SOUTH);
        return p;
    }

    JPanel footer() {
        JPanel p = new JPanel();
        p.setBackground(HEADER_COLOR);
        p.setPreferredSize(new Dimension(1080, 25));
        JLabel l = new JLabel("2026 Moremi Health System");
        l.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        l.setForeground(new Color(200, 180, 210));
        p.add(l);
        return p;
    }

    JPanel patientTab() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.setBackground(BG_WHITE);
        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        btns.setBackground(BG_WHITE);
        JButton add = btn("Add", BUTTON_SUCCESS);
        JButton find = btn("Find", BUTTON_INFO);
        JButton upd = btn("Update", BUTTON_WARNING);
        JButton del = btn("Delete", BUTTON_DANGER);
        JButton ref = btn("Refresh", BUTTON_GRAY);
        JButton sn = btn("Sort Name", BUTTON_PURPLE);
        JButton sid = btn("Sort ID", BUTTON_PURPLE);
        add.addActionListener(e -> addClient());
        find.addActionListener(e -> findClient());
        upd.addActionListener(e -> updateClient());
        del.addActionListener(e -> deleteClient());
        ref.addActionListener(e -> refreshAll());
        sn.addActionListener(e -> { db.sortByLname(); refreshAll(); });
        sid.addActionListener(e -> { db.sortByPid(); refreshAll(); });
        btns.add(add); btns.add(find); btns.add(upd); btns.add(del); btns.add(ref); btns.add(sn); btns.add(sid);
        p.add(btns, BorderLayout.NORTH);
        
        String[] cols = {"ID","First","Last","Age","Gender","Illness","Category","Ward","Bed"};
        mdl = new DefaultTableModel(cols,0) { public boolean isCellEditable(int r,int c) { return false; } };
        tbl = new JTable(mdl);
        tbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tbl.setRowHeight(26);
        tbl.setForeground(Color.BLACK);
        tbl.setBackground(BG_WHITE);
        tbl.setSelectionBackground(new Color(224, 224, 255));
        tbl.setSelectionForeground(Color.BLACK);
        tbl.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tbl.getTableHeader().setBackground(TABLE_HEADER);
        tbl.getTableHeader().setForeground(Color.WHITE);
        JScrollPane sp = new JScrollPane(tbl);
        sp.getViewport().setBackground(BG_WHITE);
        p.add(sp, BorderLayout.CENTER);
        return p;
    }

    JPanel bedTab() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.setBackground(BG_WHITE);
        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        btns.setBackground(BG_WHITE);
        JButton alloc = btn("Allocate", BUTTON_SUCCESS);
        JButton rel = btn("Release", BUTTON_DANGER);
        JButton ref = btn("Refresh", BUTTON_GRAY);
        alloc.addActionListener(e -> allocate());
        rel.addActionListener(e -> release());
        ref.addActionListener(e -> refreshAll());
        btns.add(alloc); btns.add(rel); btns.add(ref);
        p.add(btns, BorderLayout.NORTH);
        
        bedPanel = new JPanel(new GridLayout(4,5,8,8));
        bedPanel.setBackground(BG_WHITE);
        bedPanel.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        p.add(bedPanel, BorderLayout.CENTER);
        
        JPanel stats = new JPanel(new GridLayout(1,3,10,0));
        stats.setBackground(BG_WHITE);
        stats.setBorder(BorderFactory.createEmptyBorder(8,0,0,0));
        usageL = statL("Usage: 0%", BUTTON_INFO);
        totalL = statL("Total: 0", BUTTON_PURPLE);
        occL = statL("Occupied: 0/20", BUTTON_PRIMARY);
        stats.add(usageL); stats.add(totalL); stats.add(occL);
        p.add(stats, BorderLayout.SOUTH);
        return p;
    }

    JLabel statL(String t, Color c) {
        JLabel l = new JLabel(t, SwingConstants.CENTER);
        l.setFont(new Font("Segoe UI", Font.BOLD, 14));
        l.setOpaque(true);
        l.setBackground(c);
        l.setForeground(Color.WHITE);
        l.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        return l;
    }

    JPanel reportTab() {
        JPanel p = new JPanel(new BorderLayout(10,10));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.setBackground(BG_WHITE);
        
        JPanel cards = new JPanel(new GridLayout(1,6,8,0));
        cards.setBackground(BG_WHITE);
        cards.setBorder(BorderFactory.createEmptyBorder(0,0,15,0));
        String[] titles = {"Patients","Beds","Free","Used","Usage","Admitted"};
        Color[] colors = {STAT_CARD_1, STAT_CARD_2, STAT_CARD_3, STAT_CARD_4, STAT_CARD_5, STAT_CARD_6};
        for(int i=0; i<titles.length; i++) {
            JPanel card = new JPanel(new BorderLayout());
            card.setBackground(BG_WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colors[i], 2),
                BorderFactory.createEmptyBorder(10,5,10,5)
            ));
            JLabel val = new JLabel("0", SwingConstants.CENTER);
            val.setFont(new Font("Segoe UI", Font.BOLD, 20));
            val.setForeground(colors[i]);
            val.setName("stat_"+titles[i]);
            JLabel tit = new JLabel(titles[i], SwingConstants.CENTER);
            tit.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            tit.setForeground(Color.BLACK);
            card.add(val, BorderLayout.CENTER);
            card.add(tit, BorderLayout.SOUTH);
            cards.add(card);
        }
        p.add(cards, BorderLayout.NORTH);
        
        JPanel btns = new JPanel(new GridLayout(2,3,10,10));
        btns.setBackground(BG_WHITE);
        String[] btxt = {"All Patients","Free Beds","Used Beds","Full Report","Export","Refresh"};
        Color[] bcol = {BUTTON_PRIMARY, BUTTON_SUCCESS, BUTTON_DANGER, BUTTON_PURPLE, BUTTON_WARNING, BUTTON_GRAY};
        JButton[] b = new JButton[6];
        for(int i=0; i<6; i++) { b[i] = btn(btxt[i], bcol[i]); btns.add(b[i]); }
        b[0].addActionListener(e -> showAll());
        b[1].addActionListener(e -> showFree());
        b[2].addActionListener(e -> showUsed());
        b[3].addActionListener(e -> fullReport());
        b[4].addActionListener(e -> export());
        b[5].addActionListener(e -> refreshAll());
        p.add(btns, BorderLayout.CENTER);
        return p;
    }

    JButton btn(String t, Color c) {
        JButton b = new JButton(t);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBackground(c);
        b.setForeground(Color.BLACK);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 1),
            BorderFactory.createEmptyBorder(6,12,6,12)
        ));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(c.darker()); }
            public void mouseExited(MouseEvent e) { b.setBackground(c); }
        });
        return b;
    }

    void refreshAll() {
        mdl.setRowCount(0);
        for(Client c : db.all()) {
            Object[] row;
            if(c instanceof Admitted) {
                Admitted a = (Admitted)c;
                row = new Object[]{c.pid,c.fname,c.lname,c.yrs,c.gender,c.illness,c.cat,a.wardNo,a.bedNo};
            } else {
                row = new Object[]{c.pid,c.fname,c.lname,c.yrs,c.gender,c.illness,c.cat,"-","-"};
            }
            mdl.addRow(row);
        }
        refreshBeds();
        refreshStats();
    }

    void refreshBeds() {
        if(bedPanel == null) return;
        bedPanel.removeAll();
        for(String b : bCtrl.getBeds()) {
            JPanel box = new JPanel(new BorderLayout());
            box.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.DARK_GRAY, 2),
                BorderFactory.createEmptyBorder(5,5,5,5)
            ));
            boolean taken = bCtrl.taken(b);
            box.setBackground(taken ? BED_OCCUPIED : BED_AVAILABLE);
            JLabel lbl = new JLabel(b, SwingConstants.CENTER);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
            lbl.setForeground(Color.WHITE);
            box.add(lbl, BorderLayout.CENTER);
            if(taken) {
                Client c = bCtrl.get(b);
                if(c != null) {
                    JLabel n = new JLabel(c.fname+" "+c.lname, SwingConstants.CENTER);
                    n.setFont(new Font("Segoe UI", Font.PLAIN, 9));
                    n.setForeground(Color.WHITE);
                    box.add(n, BorderLayout.SOUTH);
                }
            }
            box.setToolTipText(taken ? "Taken" : "Free");
            bedPanel.add(box);
        }
        bedPanel.revalidate();
        bedPanel.repaint();
        if(usageL != null) usageL.setText(String.format("Usage: %.1f%%", bCtrl.percent()));
        if(occL != null) occL.setText("Occupied: "+bCtrl.used()+"/20");
        if(totalL != null) totalL.setText("Total: "+db.total());
    }

    void refreshStats() {
        Component[] comps = ((JPanel)((JPanel)tabs.getComponentAt(2)).getComponent(0)).getComponents();
        for(Component c : comps) {
            if(c instanceof JPanel) {
                for(Component cc : ((JPanel)c).getComponents()) {
                    if(cc instanceof JLabel && cc.getName() != null && cc.getName().startsWith("stat_")) {
                        JLabel l = (JLabel)cc;
                        String n = l.getName();
                        if(n.contains("Patients")) l.setText(String.valueOf(db.total()));
                        else if(n.contains("Beds")) l.setText("20");
                        else if(n.contains("Free")) l.setText(String.valueOf(20 - bCtrl.used()));
                        else if(n.contains("Used")) l.setText(String.valueOf(bCtrl.used()));
                        else if(n.contains("Usage")) l.setText(String.format("%.1f%%", bCtrl.percent()));
                        else if(n.contains("Admitted")) {
                            int cnt = 0; for(Client cl : db.all()) if(cl instanceof Admitted) cnt++;
                            l.setText(String.valueOf(cnt));
                        }
                    }
                }
            }
        }
    }

    void addClient() {
        JDialog d = new JDialog(this, "Add Patient", true);
        d.setLayout(new BorderLayout());
        d.setSize(480, 520);
        d.setLocationRelativeTo(this);
        
        JPanel f = new JPanel();
        f.setLayout(new GridBagLayout());
        f.setBackground(BG_WHITE);
        f.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        JTextField pid = new JTextField(15);
        JTextField fn = new JTextField(15);
        JTextField ln = new JTextField(15);
        JTextField age = new JTextField(15);
        JTextField gd = new JTextField(15);
        JTextField ill = new JTextField(15);
        JComboBox<Category> cat = new JComboBox<>(Category.values());
        
        String[] lbls = {"Patient ID:", "First Name:", "Last Name:", "Age:", "Gender:", "Illness:", "Category:"};
        JTextField[] fields = {pid, fn, ln, age, gd, ill};
        
        for(int i = 0; i < lbls.length; i++) {
            JLabel label = new JLabel(lbls[i]);
            label.setForeground(Color.BLACK);
            label.setFont(new Font("Segoe UI", Font.BOLD, 13));
            
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.gridwidth = 1;
            gbc.fill = GridBagConstraints.NONE;
            f.add(label, gbc);
            
            if(i == lbls.length - 1) {
                gbc.gridx = 1;
                gbc.gridy = i;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                f.add(cat, gbc);
            } else {
                gbc.gridx = 1;
                gbc.gridy = i;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                f.add(fields[i], gbc);
            }
        }
        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btns.setBackground(BG_WHITE);
        JButton save = btn("Save", BUTTON_SUCCESS);
        JButton can = btn("Cancel", BUTTON_DANGER);
        save.addActionListener(e -> {
            try {
                String id = pid.getText().trim();
                String fst = fn.getText().trim();
                String lst = ln.getText().trim();
                int a = Integer.parseInt(age.getText().trim());
                String g = gd.getText().trim();
                String illn = ill.getText().trim();
                Category c = (Category)cat.getSelectedItem();
                
                if(id.isEmpty() || fst.isEmpty() || lst.isEmpty() || g.isEmpty()) { 
                    JOptionPane.showMessageDialog(d, "Please fill all required fields"); 
                    return; 
                }
                
                Client cl;
                if(c == Category.INPATIENT) {
                    cl = new Admitted(id, fst, lst, a, g, illn, 1, "Unassigned");
                    if(db.save(cl)) { 
                        bCtrl.assign(id); 
                        JOptionPane.showMessageDialog(d, "Patient registered successfully!"); 
                        d.dispose(); 
                        refreshAll(); 
                    } else {
                        JOptionPane.showMessageDialog(d, "Patient ID already exists!"); 
                    }
                } else {
                    cl = new Client(id, fst, lst, a, g, illn, c);
                    if(db.save(cl)) { 
                        JOptionPane.showMessageDialog(d, "Patient registered successfully!"); 
                        d.dispose(); 
                        refreshAll(); 
                    } else {
                        JOptionPane.showMessageDialog(d, "Patient ID already exists!"); 
                    }
                }
            } catch(NumberFormatException ex) { 
                JOptionPane.showMessageDialog(d, "Please enter a valid age"); 
            } catch(Exception ex) { 
                JOptionPane.showMessageDialog(d, "Error: " + ex.getMessage()); 
            }
        });
        can.addActionListener(e -> d.dispose());
        btns.add(save); 
        btns.add(can);
        
        d.add(f, BorderLayout.CENTER); 
        d.add(btns, BorderLayout.SOUTH);
        d.setVisible(true);
    }

    void findClient() {
        String id = JOptionPane.showInputDialog(this, "Enter Patient ID:");
        if(id != null && !id.trim().isEmpty()) {
            Client c = db.find(id.trim());
            if(c != null) {
                JOptionPane.showMessageDialog(this, c.info(), "Patient Found", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Patient not found!", "Search Result", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    void updateClient() {
        String id = JOptionPane.showInputDialog(this, "Enter Patient ID:");
        if(id == null || id.trim().isEmpty()) return;
        Client cl = db.find(id.trim());
        if(cl == null) { 
            JOptionPane.showMessageDialog(this, "Patient not found!"); 
            return; 
        }
        
        JDialog d = new JDialog(this, "Update Patient", true);
        d.setLayout(new BorderLayout());
        d.setSize(480, 520);
        d.setLocationRelativeTo(this);
        
        JPanel f = new JPanel();
        f.setLayout(new GridBagLayout());
        f.setBackground(BG_WHITE);
        f.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        JTextField fn = new JTextField(cl.fname, 15);
        JTextField ln = new JTextField(cl.lname, 15);
        JTextField age = new JTextField(String.valueOf(cl.yrs), 15);
        JTextField gd = new JTextField(cl.gender, 15);
        JTextField ill = new JTextField(cl.illness, 15);
        JComboBox<Category> cat = new JComboBox<>(Category.values());
        cat.setSelectedItem(cl.cat);
        
        String[] lbls = {"First Name:", "Last Name:", "Age:", "Gender:", "Illness:", "Category:"};
        JTextField[] fields = {fn, ln, age, gd, ill};
        
        for(int i = 0; i < lbls.length; i++) {
            JLabel label = new JLabel(lbls[i]);
            label.setForeground(Color.BLACK);
            label.setFont(new Font("Segoe UI", Font.BOLD, 13));
            
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.gridwidth = 1;
            gbc.fill = GridBagConstraints.NONE;
            f.add(label, gbc);
            
            if(i == lbls.length - 1) {
                gbc.gridx = 1;
                gbc.gridy = i;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                f.add(cat, gbc);
            } else {
                gbc.gridx = 1;
                gbc.gridy = i;
                gbc.gridwidth = 1;
                gbc.fill = GridBagConstraints.HORIZONTAL;
                f.add(fields[i], gbc);
            }
        }
        
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btns.setBackground(BG_WHITE);
        JButton save = btn("Update", BUTTON_SUCCESS);
        JButton can = btn("Cancel", BUTTON_DANGER);
        save.addActionListener(e -> {
            try {
                String fst = fn.getText().trim();
                String lst = ln.getText().trim();
                int a = Integer.parseInt(age.getText().trim());
                String g = gd.getText().trim();
                String illn = ill.getText().trim();
                Category c = (Category)cat.getSelectedItem();
                
                if(fst.isEmpty() || lst.isEmpty() || g.isEmpty()) { 
                    JOptionPane.showMessageDialog(d, "Please fill all required fields"); 
                    return; 
                }
                
                if(db.edit(id.trim(), fst, lst, a, g, illn, c)) {
                    if(c == Category.INPATIENT && !(cl instanceof Admitted)) {
                        bCtrl.assign(id.trim());
                    }
                    JOptionPane.showMessageDialog(d, "Patient updated successfully!"); 
                    d.dispose(); 
                    refreshAll();
                }
            } catch(NumberFormatException ex) { 
                JOptionPane.showMessageDialog(d, "Please enter a valid age"); 
            } catch(Exception ex) { 
                JOptionPane.showMessageDialog(d, "Error: " + ex.getMessage()); 
            }
        });
        can.addActionListener(e -> d.dispose());
        btns.add(save); 
        btns.add(can);
        
        d.add(f, BorderLayout.CENTER); 
        d.add(btns, BorderLayout.SOUTH);
        d.setVisible(true);
    }

    void deleteClient() {
        String id = JOptionPane.showInputDialog(this, "Enter Patient ID:");
        if(id == null || id.trim().isEmpty()) return;
        Client c = db.find(id.trim());
        if(c == null) { 
            JOptionPane.showMessageDialog(this, "Patient not found!"); 
            return; 
        }
        int conf = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete " + c.fname + " " + c.lname + "?");
        if(conf == JOptionPane.YES_OPTION) {
            if(c instanceof Admitted) {
                for(String b : bCtrl.getMap().keySet()) {
                    if(bCtrl.getMap().get(b).equals(id.trim())) { 
                        bCtrl.release(b); 
                        break; 
                    }
                }
            }
            if(db.remove(id.trim())) { 
                JOptionPane.showMessageDialog(this, "Patient deleted successfully!"); 
                refreshAll(); 
            }
        }
    }

    void allocate() {
        String id = JOptionPane.showInputDialog(this, "Enter Patient ID:");
        if(id == null || id.trim().isEmpty()) return;
        Client c = db.find(id.trim());
        if(c == null) { 
            JOptionPane.showMessageDialog(this, "Patient not found!"); 
            return; 
        }
        if(c.cat != Category.INPATIENT) { 
            JOptionPane.showMessageDialog(this, "Only inpatients can be allocated a bed!"); 
            return; 
        }
        if(bCtrl.isFull()) { 
            JOptionPane.showMessageDialog(this, "No beds available!"); 
            return; 
        }
        if(bCtrl.assign(id.trim())) { 
            JOptionPane.showMessageDialog(this, "Bed allocated successfully!"); 
            refreshAll(); 
        } else {
            JOptionPane.showMessageDialog(this, "Patient already has a bed!"); 
        }
    }

    void release() {
        String b = JOptionPane.showInputDialog(this, "Enter Bed ID (B01-B20):");
        if(b == null || b.trim().isEmpty()) return;
        if(bCtrl.release(b.trim().toUpperCase())) { 
            JOptionPane.showMessageDialog(this, "Bed released successfully!"); 
            refreshAll(); 
        } else {
            JOptionPane.showMessageDialog(this, "Bed is not occupied or does not exist!"); 
        }
    }

    void showAll() {
        StringBuilder sb = new StringBuilder("=== ALL PATIENTS ===\n\n");
        if(db.total() == 0) {
            sb.append("No patients registered.");
        } else {
            for(Client c : db.all()) {
                sb.append(c.info()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(this, sb.toString(), "Patient List", JOptionPane.INFORMATION_MESSAGE);
    }

    void showFree() {
        StringBuilder sb = new StringBuilder("=== AVAILABLE BEDS ===\n\n");
        boolean f = false;
        for(String b : bCtrl.getBeds()) {
            if(!bCtrl.taken(b)) { 
                sb.append(b).append(" "); 
                f = true; 
            }
        }
        if(!f) sb.append("No available beds.");
        JOptionPane.showMessageDialog(this, sb.toString(), "Available Beds", JOptionPane.INFORMATION_MESSAGE);
    }

    void showUsed() {
        StringBuilder sb = new StringBuilder("=== OCCUPIED BEDS ===\n\n");
        boolean f = false;
        for(String b : bCtrl.getBeds()) {
            if(bCtrl.taken(b)) {
                Client c = bCtrl.get(b);
                sb.append(b).append(" - ").append(c != null ? c.fname + " " + c.lname : "Unknown").append("\n");
                f = true;
            }
        }
        if(!f) sb.append("No beds occupied.");
        JOptionPane.showMessageDialog(this, sb.toString(), "Occupied Beds", JOptionPane.INFORMATION_MESSAGE);
    }

    void fullReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append("     MOREMI HOSPITAL REPORT\n");
        sb.append("========================================\n\n");
        sb.append("Statistics:\n");
        sb.append("----------------------------------------\n");
        sb.append("Total Patients: ").append(db.total()).append("\n");
        sb.append("Total Beds: 20\n");
        sb.append("Occupied Beds: ").append(bCtrl.used()).append("\n");
        sb.append("Available Beds: ").append(20 - bCtrl.used()).append("\n");
        sb.append("Occupancy Rate: ").append(String.format("%.1f%%", bCtrl.percent())).append("\n\n");
        sb.append("Patient List:\n");
        sb.append("----------------------------------------\n");
        if(db.total() == 0) {
            sb.append("No patients registered.\n");
        } else {
            for(Client c : db.all()) {
                sb.append(c.info()).append("\n");
            }
        }
        sb.append("\n");
        sb.append("Bed Layout:\n");
        sb.append("----------------------------------------\n");
        for(int r=0; r<4; r++) {
            for(int c=0; c<5; c++) {
                int idx = r*5+c;
                if(idx < 20) {
                    String b = bCtrl.getBeds()[idx];
                    sb.append(bCtrl.taken(b) ? b + "*" : b).append(" ");
                }
            }
            sb.append("\n");
        }
        sb.append("\n* = Occupied\n");
        sb.append("========================================\n");
        
        JTextArea ta = new JTextArea(sb.toString());
        ta.setFont(new Font("Monospaced", Font.PLAIN, 12));
        ta.setEditable(false);
        ta.setForeground(Color.BLACK);
        ta.setBackground(BG_WHITE);
        JScrollPane sp = new JScrollPane(ta);
        sp.setPreferredSize(new Dimension(580, 480));
        JOptionPane.showMessageDialog(this, sp, "Full Report", JOptionPane.INFORMATION_MESSAGE);
    }

    void export() {
        String r = fullReportText();
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new java.io.File("Moremi_Report.txt"));
        if(fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try { 
                java.io.FileWriter w = new java.io.FileWriter(fc.getSelectedFile()); 
                w.write(r); 
                w.close();
                JOptionPane.showMessageDialog(this, "Report exported successfully!"); 
            } catch(Exception ex) { 
                JOptionPane.showMessageDialog(this, "Error exporting report: " + ex.getMessage()); 
            }
        }
    }

    String fullReportText() {
        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append("     MOREMI HOSPITAL REPORT\n");
        sb.append("     ").append(new java.util.Date()).append("\n");
        sb.append("========================================\n\n");
        sb.append("Statistics:\n");
        sb.append("----------------------------------------\n");
        sb.append("Total Patients: ").append(db.total()).append("\n");
        sb.append("Total Beds: 20\n");
        sb.append("Occupied Beds: ").append(bCtrl.used()).append("\n");
        sb.append("Available Beds: ").append(20 - bCtrl.used()).append("\n");
        sb.append("Occupancy Rate: ").append(String.format("%.1f%%", bCtrl.percent())).append("\n\n");
        sb.append("Patient List:\n");
        sb.append("----------------------------------------\n");
        if(db.total() == 0) {
            sb.append("No patients registered.\n");
        } else {
            for(Client c : db.all()) {
                sb.append(c.info()).append("\n");
            }
        }
        sb.append("\n");
        sb.append("Bed Layout:\n");
        sb.append("----------------------------------------\n");
        for(int r=0; r<4; r++) {
            for(int c=0; c<5; c++) {
                int idx = r*5+c;
                if(idx < 20) {
                    String b = bCtrl.getBeds()[idx];
                    sb.append(bCtrl.taken(b) ? b + "*" : b).append(" ");
                }
            }
            sb.append("\n");
        }
        sb.append("\n* = Occupied\n");
        sb.append("========================================\n");
        return sb.toString();
    }

    public static void main(String[] args) {
        try { 
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); 
        } catch(Exception e) {}
        SwingUtilities.invokeLater(() -> { 
            new NATASHA_MOREMI_Assignment1().setVisible(true); 
        });
    }
}