package com.mycompany.natasha_moremi_assignment1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.mycompany.natasha_moremi_assignment1.NATASHA_MOREMI_Assignment1.*;

public class NATASHA_MOREMI_Assignment1_JUnit {
    
    Store db;
    BedCtrl beds;
    
    @BeforeEach
    void setup() {
        db = new Store();
        beds = new BedCtrl(db);
    }
    
    @Test
    void testAddPatient() {
        Client c = new Client("N001", "Thabo", "Mokoena", 30, "Male", "Fever", Category.OUTPATIENT);
        assertTrue(db.save(c));
        assertEquals(1, db.total());
        assertNotNull(db.find("N001"));
    }
    
    @Test
    void testFindPatient() {
        db.save(new Client("N002", "Lerato", "Nkosi", 25, "Female", "Cough", Category.OUTPATIENT));
        assertNotNull(db.find("N002"));
        assertNull(db.find("N999"));
    }
    
    @Test
    void testUpdatePatient() {
        Client c = new Client("N003", "Sipho", "Zulu", 40, "Male", "Pain", Category.OUTPATIENT);
        db.save(c);
        assertTrue(db.edit("N003", "Siphiwe", "Zulu", 41, "Male", "Severe", Category.INPATIENT));
        Client up = db.find("N003");
        assertEquals("Siphiwe", up.fname);
        assertEquals(41, up.yrs);
        assertEquals(Category.INPATIENT, up.cat);
    }
    
    @Test
    void testDeletePatient() {
        db.save(new Client("N004", "Zanele", "Dlamini", 32, "Female", "Flu", Category.OUTPATIENT));
        assertEquals(1, db.total());
        assertTrue(db.remove("N004"));
        assertEquals(0, db.total());
        assertNull(db.find("N004"));
    }
    
    @Test
    void testAllocateBed() {
        Admitted a = new Admitted("N005", "Nomalanga", "Mthembu", 55, "Female", "Heart", 1, "Unassigned");
        db.save(a);
        assertTrue(beds.assign("N005"));
        assertEquals(1, beds.used());
        assertNotNull(beds.get("B01"));
    }
    
    @Test
    void testReleaseBed() {
        Admitted a = new Admitted("N006", "Thandeka", "Khumalo", 29, "Female", "Asthma", 1, "Unassigned");
        db.save(a);
        beds.assign("N006");
        assertEquals(1, beds.used());
        assertTrue(beds.release("B01"));
        assertEquals(0, beds.used());
    }
    
    @Test
    void testNoDuplicateIDs() {
        Client c1 = new Client("N007", "Ayanda", "Ngcobo", 24, "Female", "Cold", Category.OUTPATIENT);
        Client c2 = new Client("N007", "Ayanda", "Ngcobo", 24, "Female", "Cold", Category.OUTPATIENT);
        assertTrue(db.save(c1));
        assertFalse(db.save(c2));
        assertEquals(1, db.total());
    }
    
    @Test
    void testNoOccupiedBed() {
        Admitted a1 = new Admitted("N008", "Bongani", "Mkhize", 47, "Male", "Pneumonia", 1, "Unassigned");
        Admitted a2 = new Admitted("N009", "Nomvula", "Mabaso", 35, "Female", "Broken", 1, "Unassigned");
        db.save(a1); db.save(a2);
        assertTrue(beds.assign("N008"));
        assertTrue(beds.assign("N009"));
        assertEquals(2, beds.used());
        assertFalse(beds.assign("N008"));
    }
    
    @Test
    void testNoBedsLeft() {
        for(int i=0; i<20; i++) {
            String id = String.format("N%03d", i+1);
            Admitted a = new Admitted(id, "P"+i, "Test", 30+i, "Male", "Cond", 1, "Unassigned");
            db.save(a);
            beds.assign(id);
        }
        assertTrue(beds.isFull());
        assertEquals(20, beds.used());
        Admitted extra = new Admitted("N021", "Extra", "Patient", 25, "Female", "Flu", 1, "Unassigned");
        db.save(extra);
        assertFalse(beds.assign("N021"));
    }
    
    @Test
    void testSortBySurname() {
        db.save(new Client("N003", "Sifiso", "Zulu", 30, "Male", "Cold", Category.OUTPATIENT));
        db.save(new Client("N001", "Lindiwe", "Mthembu", 25, "Female", "Flu", Category.OUTPATIENT));
        db.save(new Client("N002", "Mpho", "Nkosi", 35, "Male", "Cough", Category.OUTPATIENT));
        db.sortByLname();
        var list = db.all();
        assertEquals("Mthembu", list.get(0).lname);
        assertEquals("Nkosi", list.get(1).lname);
        assertEquals("Zulu", list.get(2).lname);
    }
    
    @Test
    void testSortByID() {
        db.save(new Client("N003", "Sifiso", "Zulu", 30, "Male", "Cold", Category.OUTPATIENT));
        db.save(new Client("N001", "Lindiwe", "Mthembu", 25, "Female", "Flu", Category.OUTPATIENT));
        db.save(new Client("N002", "Mpho", "Nkosi", 35, "Male", "Cough", Category.OUTPATIENT));
        db.sortByPid();
        var list = db.all();
        assertEquals("N001", list.get(0).pid);
        assertEquals("N002", list.get(1).pid);
        assertEquals("N003", list.get(2).pid);
    }
}